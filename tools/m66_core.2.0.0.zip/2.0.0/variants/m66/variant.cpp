/*
 *  Created on: 01.15.2019
 *      Author: Georgi Angelov
 */

#include <Arduino.h>

HardwareSerial Serial(UART_PORT1);
HardwareSerial Serial1(UART_PORT2);
HardwareSerial Serial2(UART_PORT3);

HardwareSerial Virtual(VIRTUAL_PORT1);
HardwareSerial Virtual1(VIRTUAL_PORT2);