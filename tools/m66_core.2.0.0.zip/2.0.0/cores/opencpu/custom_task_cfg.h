
TASK_ITEM(proc_main_task,   main_task_id,   10*1024, DEFAULT_VALUE1, DEFAULT_VALUE2)
TASK_ITEM(proc_reserved1,   reserved1_id,   10*1024, DEFAULT_VALUE1, DEFAULT_VALUE2)
TASK_ITEM(proc_reserved2,   reserved2_id,   10*1024, DEFAULT_VALUE1, DEFAULT_VALUE2)
TASK_ITEM(proc_arduino,     arduino3_id,    10*1024, DEFAULT_VALUE1, DEFAULT_VALUE2)





